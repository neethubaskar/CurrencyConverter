from django.shortcuts import render, redirect
from django.views.generic.base import TemplateView
from django.views import View
from django.http import JsonResponse

import requests
import json

# Create your views here.

class CurrencyPageView(TemplateView):
    """ template rendering view """
    template_name = "main.html"

    def get_context_data(self, **kwargs):
        context = super(CurrencyPageView, self).get_context_data(**kwargs)
        return context


class GetCurrecyData(View):
    """Currency conversion view"""
    def post(self,request,*args,**kwargs):
        try:

            flt_amount = float(request.POST.get("current_amount"))
            str_home_currency = request.POST.get("home_currency")
            str_target_currency = request.POST.get("target_currency")

            str_url = 'http://data.fixer.io/api/latest?access_key=40eac7a32ba84e0369830d99248246b7'
            result = requests.get(str_url)
            dct_result = result.json()

            flt_target_amount = 0
            if dct_result['success']:

                if all (key in dct_result['rates'] for key in (str_home_currency,str_target_currency)):
                    if str_target_currency == "EUR":
                        flt_target_amount = flt_amount / dct_result['rates'][str_home_currency]
                    elif str_home_currency == 'EUR':
                        flt_target_amount = flt_amount * dct_result['rates'][str_target_currency]
                    else:
                        flt_hme_currency_euro = flt_amount / dct_result['rates'][str_home_currency]
                        flt_target_amount = flt_hme_currency_euro * dct_result['rates'][str_target_currency]
                else:
                    return JsonResponse({'status':'success','data':'Currency not found'})
            else:
                return JsonResponse({'status':'success','data':'Invalid Access'})

            flt_target_amount = round(flt_target_amount, 2)
            return JsonResponse({'status':'success','data':flt_target_amount})
        except Exception as e:
            return JsonResponse({'status':'failed'})
