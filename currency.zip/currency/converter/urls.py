from django.conf.urls import url
from converter import views

urlpatterns = [
        url(r'^$', views.CurrencyPageView.as_view(), name='main'),
        url(r'^currency-data/$',views.GetCurrecyData.as_view(), name='currency-data'),

    ]
